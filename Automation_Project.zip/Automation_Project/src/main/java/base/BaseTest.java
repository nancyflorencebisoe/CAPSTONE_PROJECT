package base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import driver.DriverFactory;
import utils.ReportManager;

public class BaseTest {
	protected WebDriver driver;
	
	@BeforeSuite
	public void beforeSuite() {
		ReportManager.startReport();
	}
	
	@AfterSuite
	public void afterSuite() {
		ReportManager.endReport();
	}
	
	@Parameters("browser")
	@BeforeMethod
	public void setup(@Optional("chrome") String browser) {
		driver = DriverFactory.initDriver(browser);
	}
	
	@AfterMethod
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}
}

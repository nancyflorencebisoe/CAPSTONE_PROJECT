package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
	private WebDriver driver;
	
	By accountDropdown = By.id("listAccounts");
	By goButton = By.id("btnGetAccount");
	By availableBalance = By.xpath("//td[normalize-space(text())='Available balance']/following-sibling::td");
	By electricBillAmount = By.xpath("//td[normalize-space(text())='Electric Bill']/following-sibling::td");
	
	public AccountPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickMyAccount() {
		driver.findElement(By.linkText("View Account Summary")).click();
	}
	
	public void viewAccountDetails() {
		driver.findElement(accountDropdown).click();
		driver.findElement(goButton).click();
	}
	
	public String getAvailableBalance() {
		return driver.findElement(availableBalance).getText();
	}
	
	public String getElectricBillAmount() {
		return driver.findElement(electricBillAmount).getText();
	}

}

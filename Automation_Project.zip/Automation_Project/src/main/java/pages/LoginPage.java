package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	private WebDriver driver;
	
	By signInLink = By.linkText("Sign In");
	By usernameField = By.name("uid");
	By passwordField = By.name("passw");
	By loginBtn = By.name("btnSubmit");
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickSignIn() {
		driver.findElement(signInLink).click();
	}
	
	public void login(String username, String password) {
		driver.findElement(usernameField).sendKeys(username);
		driver.findElement(passwordField).sendKeys(password);
		driver.findElement(loginBtn).click();
	}

}

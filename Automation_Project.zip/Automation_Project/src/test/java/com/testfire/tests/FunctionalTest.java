package com.testfire.tests;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AccountPage;
import pages.LoginPage;
import utils.ExcelUtils;
import utils.ReportManager;

public class FunctionalTest extends BaseTest {
	
	@Parameters("browser")
	@Test
	public void loginAndValidateAccount(String browser) {
		try {
			
			ReportManager.createTest("Functional Test: Login and Account Validation");
			
			ExcelUtils.loadExcelFile("src/test/resources/TestData.xlsx", "LoginData");
			String username = ExcelUtils.getCellData(1, 0);
			String password = ExcelUtils.getCellData(1, 1);
			ReportManager.logInfo("Loaded Excel data");
			
			driver.get("https://demo.testfire.net");
			ReportManager.logInfo("Opened URL");
			
			LoginPage loginPage = new LoginPage(driver);
			loginPage.clickSignIn();
			ReportManager.logInfo("Clicked Sign In");
			
			loginPage.login(username, password);
			ReportManager.logInfo("Entered login details");
			
			Assert.assertTrue(driver.getTitle().contains("Altoro Mutual"));
			ReportManager.logPass("Login Successful");
			
			AccountPage accountPage = new AccountPage(driver);
			accountPage.clickMyAccount();
			accountPage.viewAccountDetails();
			ReportManager.logInfo("Viewed account details");
			
			String availableBalance = accountPage.getAvailableBalance();
			Assert.assertNotNull(availableBalance);
			Assert.assertFalse(availableBalance.isEmpty());
			ReportManager.logPass("Available balance verified: " + availableBalance);
			
			String electricBillAmount = accountPage.getElectricBillAmount();
			Assert.assertNotNull(electricBillAmount);
			Assert.assertFalse(electricBillAmount.isEmpty());
			ReportManager.logPass("Electric bill amount verified: " + electricBillAmount);
			
		} catch (Exception e) {
			ReportManager.logFail("Test failed: " + e.getMessage());
			Assert.fail("Test failed due to: " + e.getMessage());
		}
	}
}
